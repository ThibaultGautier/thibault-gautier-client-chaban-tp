import React, { Component } from 'react';

class error404Page extends Component{
    render(){
        return(
            <div>404</div>
        )
    }
}

export default error404Page;