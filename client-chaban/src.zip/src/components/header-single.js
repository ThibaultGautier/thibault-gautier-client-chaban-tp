import React, { Component } from 'react';
import BackButton from './backbutton';

class HeaderSingle extends Component {
    render(){
        return(
            <header>
                <BackButton />
            </header>
        )
    }
}

export default HeaderSingle;